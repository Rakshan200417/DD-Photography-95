import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

export default function AdminDashboard() {
  const admin = localStorage.getItem("admin");

  if (!admin) {
    alert("Unauthorized! Please login as admin.");
    window.location.href = "/adminlogin";
    return null;
  }

  return (
    <>
      <Navbar />
      <div className="container my-5">
        <h2 className="mb-4 text-center" data-aos="fade-up">Admin Dashboard</h2>
        <div className="row">
          <div className="col-md-6 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div className="card shadow p-4 text-center">
              <h5>Manage Categories</h5>
              <p>Add, update, or delete photo categories.</p>
              <button className="btn btn-primary">Go</button>
            </div>
          </div>
          <div className="col-md-6 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div className="card shadow p-4 text-center">
              <h5>Manage Orders</h5>
              <p>Check and confirm user orders/bookings.</p>
              <button className="btn btn-primary">Go</button>
            </div>
          </div>
        </div>
        <div className="text-center mt-5">
          <button className="btn btn-danger" onClick={() => { localStorage.removeItem("admin"); window.location.href="/adminlogin"; }}>
            Logout
          </button>
        </div>
      </div>
      <Footer />
    </>
  );
}
