import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import HeroCarousel from "../components/HeroCarousel";

export default function Home() {
  return (
    <>
      <Navbar />
      <HeroCarousel />

      <div className="container my-5">
        <h2 className="text-center mb-4" data-aos="fade-up">Featured Categories</h2>
        <div className="row">
          <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <div className="card shadow">
              <img src="https://source.unsplash.com/400x300/?wedding" className="card-img-top" alt="Wedding" />
              <div className="card-body text-center">
                <h5 className="card-title">Wedding Photography</h5>
                <p className="card-text">Capture your big day in perfect style.</p>
              </div>
            </div>
          </div>
          <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="200">
            <div className="card shadow">
              <img src="https://source.unsplash.com/400x300/?portrait" className="card-img-top" alt="Portrait" />
              <div className="card-body text-center">
                <h5 className="card-title">Portrait Photography</h5>
                <p className="card-text">Create timeless personal memories.</p>
              </div>
            </div>
          </div>
          <div className="col-md-4 mb-4" data-aos="fade-up" data-aos-delay="300">
            <div className="card shadow">
              <img src="https://source.unsplash.com/400x300/?nature" className="card-img-top" alt="Nature" />
              <div className="card-body text-center">
                <h5 className="card-title">Nature & Landscape</h5>
                <p className="card-text">Capture the beauty of the outdoors.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
