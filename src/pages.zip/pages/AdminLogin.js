import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function AdminLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAdminLogin = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await axios.post("http://localhost:8080/api/admin/login", {
        username,
        password,
      });

      // Example: backend returns { status: "success", token: "..." }
      if (res.data.status === "success") {
        // Save admin info / token in localStorage
        localStorage.setItem("admin", username);
        if (res.data.token) localStorage.setItem("adminToken", res.data.token);

        alert("Admin logged in successfully!");
        navigate("/admin"); // Redirect to admin dashboard
      } else {
        alert(res.data.message || "❌ Invalid admin credentials!");
      }
    } catch (error) {
      console.error(error);
      alert(
        (error.response && error.response.data && error.response.data.message) ||
          "❌ Something went wrong with admin login!"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container col-md-4 mt-5 p-4 shadow rounded">
      <h3 className="text-center mb-3">Admin Login</h3>

      <form onSubmit={handleAdminLogin}>
        <div className="mb-3">
          <label className="form-label">Admin Username</label>
          <input
            type="text"
            className="form-control"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Password</label>
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button className="btn btn-dark w-100" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>
    </div>
  );
}
