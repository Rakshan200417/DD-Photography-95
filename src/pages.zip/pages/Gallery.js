import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useNavigate } from "react-router-dom";

export default function Gallery() {
  const navigate = useNavigate();

  const categories = [
    { title: "Wedding", img: "https://source.unsplash.com/400x300/?wedding" },
    { title: "Portrait", img: "https://source.unsplash.com/400x300/?portrait" },
    { title: "Nature", img: "https://source.unsplash.com/400x300/?nature" },
    { title: "Events", img: "https://source.unsplash.com/400x300/?event" },
    { title: "Street", img: "https://source.unsplash.com/400x300/?street" },
    { title: "Fashion", img: "https://source.unsplash.com/400x300/?fashion" },
  ];

  const packageTypes = ["Normal", "Medium", "Luxurious"];

  const handleOrder = (category, type) => {
    navigate(`/order?category=${category}&type=${type}`);
  };

  return (
    <>
      <Navbar />

      <div className="container my-5">
        <h2 className="text-center mb-4" data-aos="fade-up">Photography Packages</h2>

        <div className="row">
          {categories.map((cat, index) => (
            <div className="col-md-4 mb-4" key={index} data-aos="fade-up" data-aos-delay={index * 80}>
              <div className="card shadow">
                <img src={cat.img} className="card-img-top" alt={cat.title} />
                <div className="card-body">
                  <h4 className="text-center">{cat.title}</h4>
                  <hr />

                  {/* Packages */}
                  {packageTypes.map((type, i) => (
                    <div className="border rounded p-3 mb-3" key={i}>
                      <h5>{type} Package</h5>
                      <p>Best {type.toLowerCase()} package for {cat.title} photography.</p>

                      <button
                        className="btn btn-primary w-100"
                        onClick={() => handleOrder(cat.title, type)}
                      >
                        Order Now
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </>
  );
}
