import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";
import { useLocation } from "react-router-dom";

export default function Order() {
  const location = useLocation();

  const query = new URLSearchParams(location.search);
  const selectedCategory = query.get("category") || "";
  const selectedType = query.get("type") || "";

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    category: selectedCategory,
    packageType: selectedType,
    date: "",
    notes: "",
  });

  const [showModal, setShowModal] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowModal(true);
  };

  return (
    <>
      <Navbar />

      <div className="container my-5">
        <h2 className="text-center mb-4" data-aos="fade-up">
          Book Your Photography Package
        </h2>

        <form
          onSubmit={handleSubmit}
          data-aos="fade-up"
          className="mx-auto"
          style={{ maxWidth: "600px" }}
        >
          <div className="mb-3">
            <label>Name</label>
            <input type="text" name="name" className="form-control" required onChange={handleChange} />
          </div>

          <div className="mb-3">
            <label>Email</label>
            <input type="email" name="email" className="form-control" required onChange={handleChange} />
          </div>

          <div className="mb-3">
            <label>Phone</label>
            <input type="tel" name="phone" className="form-control" required onChange={handleChange} />
          </div>

          <div className="mb-3">
            <label>Category</label>
            <select name="category" className="form-select" value={form.category} onChange={handleChange} required>
              <option value="">Select Category</option>
              <option value="Wedding">Wedding</option>
              <option value="Portrait">Portrait</option>
              <option value="Nature">Nature</option>
              <option value="Events">Events</option>
              <option value="Street">Street</option>
              <option value="Fashion">Fashion</option>
            </select>
          </div>

          <div className="mb-3">
            <label>Package Type</label>
            <select
              name="packageType"
              className="form-select"
              value={form.packageType}
              onChange={handleChange}
              required
            >
              <option value="">Select Package Type</option>
              <option value="Normal">Normal</option>
              <option value="Medium">Medium</option>
              <option value="Luxurious">Luxurious</option>
            </select>
          </div>

          <div className="mb-3">
            <label>Date</label>
            <input type="date" name="date" className="form-control" required onChange={handleChange} />
          </div>

          <div className="mb-3">
            <label>Notes</label>
            <textarea name="notes" className="form-control" onChange={handleChange}></textarea>
          </div>

          <button type="submit" className="btn btn-primary w-100">
            Submit Booking
          </button>
        </form>
      </div>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Booking Confirmed</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          Thank you {form.name}! <br />
          Your booking for <strong>{form.category}</strong> –{" "}
          <strong>{form.packageType}</strong> package on <strong>{form.date}</strong>
          has been successfully submitted.
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      <Footer />
    </>
  );
}
