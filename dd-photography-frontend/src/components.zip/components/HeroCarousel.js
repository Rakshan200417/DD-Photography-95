import Carousel from 'react-bootstrap/Carousel';

export default function HeroCarousel() {
  return (
    <Carousel className="mb-5">
      <Carousel.Item>
        <img className="d-block w-100" src="https://source.unsplash.com/1200x500/?photography,landscape" alt="Slide 1" />
        <Carousel.Caption>
          <h2>Stunning Landscapes</h2>
          <p>Capture nature's beauty with our photography.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img className="d-block w-100" src="https://source.unsplash.com/1200x500/?photography,portrait" alt="Slide 2" />
        <Carousel.Caption>
          <h2>Portrait Photography</h2>
          <p>Memorable moments with your loved ones.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img className="d-block w-100" src="https://source.unsplash.com/1200x500/?photography,event" alt="Slide 3" />
        <Carousel.Caption>
          <h2>Event & Wedding Photography</h2>
          <p>Make every event unforgettable.</p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}
