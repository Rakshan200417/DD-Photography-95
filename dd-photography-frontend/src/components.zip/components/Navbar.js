import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { FaCameraRetro } from "react-icons/fa";

export default function Navbar() {
  const [isUser, setIsUser] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const user = localStorage.getItem("user");
    const admin = localStorage.getItem("admin");

    setIsUser(!!user);
    setIsAdmin(!!admin);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("admin");
    window.location.href = "/";
  };

  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: "easeOut" }}
      className="navbar navbar-expand-lg navbar-dark bg-dark shadow-lg"
      style={{ background: "linear-gradient(90deg, #0f0f0f, #1b1b1b)" }}
    >
      <div className="container">

        {/* Brand Logo */}
        <motion.div
          whileHover={{ scale: 1.08 }}
          transition={{ duration: 0.3 }}
        >
          <Link className="navbar-brand d-flex align-items-center gap-2" to="/">
            <FaCameraRetro size={28} color="#ffd369" />
            <span style={{ fontWeight: "bold", letterSpacing: "1px" }}>DD Photography</span>
          </Link>
        </motion.div>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto gap-2">

            {/* NAV LINKS */}
            {[
              { name: "Home", link: "/" },
              { name: "Gallery", link: "/gallery" },
              { name: "About/FAQ", link: "/about" },
              { name: "Order", link: "/order" }
            ].map((item) => (
              <motion.li
                key={item.name}
                className="nav-item"
                whileHover={{ scale: 1.1 }}
                transition={{ duration: 0.2 }}
              >
                <Link className="nav-link text-white fw-semibold" to={item.link}>
                  {item.name}
                </Link>
              </motion.li>
            ))}

            {/* Admin Dashboard */}
            {isAdmin && (
              <motion.li whileHover={{ scale: 1.1 }} className="nav-item">
                <Link className="nav-link text-warning fw-bold" to="/admindashboard">
                  Admin Dashboard
                </Link>
              </motion.li>
            )}

            {/* Login */}
            {!isUser && !isAdmin && (
              <motion.li whileHover={{ scale: 1.1 }} className="nav-item">
                <Link className="nav-link text-info fw-bold" to="/login">
                  Login
                </Link>
              </motion.li>
            )}

            {/* Logout Button */}
            {(isUser || isAdmin) && (
              <motion.li whileHover={{ scale: 1.1 }} className="nav-item">
                <button
                  className="btn btn-danger ms-2 px-3 fw-bold"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </motion.li>
            )}

          </ul>
        </div>
      </div>
    </motion.nav>
  );
}
